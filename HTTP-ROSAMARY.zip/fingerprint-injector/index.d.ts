export * from './fingerprint-injector';
//# sourceMappingURL=index.d.ts.map