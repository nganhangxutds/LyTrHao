"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MISSING_VALUE_DATASET_TOKEN = exports.STRINGIFIED_PREFIX = void 0;
exports.STRINGIFIED_PREFIX = '*STRINGIFIED*';
exports.MISSING_VALUE_DATASET_TOKEN = '*MISSING_VALUE*';
//# sourceMappingURL=constants.js.map